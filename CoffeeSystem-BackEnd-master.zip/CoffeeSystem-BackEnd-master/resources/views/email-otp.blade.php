<!DOCTYPE html>
<html>
<head>
    <title>OTP Email</title>
</head>
<body>
    <p>Hello,</p>
    <p>Your OTP code is: {{$otp}}</p>
    <p>Please use this code to complete your verification process.</p>
</body>
</html>
