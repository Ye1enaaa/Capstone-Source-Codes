<!DOCTYPE html>
<html>
<head>
    <title>Special Key Email</title>
</head>
<body>
    <p>Hello,</p>
    <p>Your special key is: {{$randomKey}}</p>
    <p>Please use this code to complete your registration process.</p>
</body>
</html>
