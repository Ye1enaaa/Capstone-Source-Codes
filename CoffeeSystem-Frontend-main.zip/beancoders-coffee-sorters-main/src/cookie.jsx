/** @format */

const localhost_domain = "192.168.100.10";

export default localhost_domain;