/** @format */

import React from "react";

const Path = () => {
  return <div></div>;
};

export default Path;
