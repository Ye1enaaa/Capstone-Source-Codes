/** @format */

const image_endpoint = "http://192.168.100.10:8000";

export default image_endpoint;
