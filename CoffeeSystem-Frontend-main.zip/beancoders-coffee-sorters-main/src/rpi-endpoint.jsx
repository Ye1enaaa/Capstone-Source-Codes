const rpi_endpoint = "http://192.168.254.181:5000";

export default rpi_endpoint;