/** @format */

const api_endpoint = "http://192.168.100.10:8000/api";

export default api_endpoint;
